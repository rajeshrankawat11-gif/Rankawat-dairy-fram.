RANKAWAT DAIRY FARM — COMPLETE BUILD PACKAGE

This package contains:
- source/rankawat-dairy-farm-v1-android-source.zip — the Android source project
- .github/workflows/build-apk.yml — GitHub Actions workflow that extracts the source ZIP and builds the APK

The workflow creates an artifact named:
Rankawat-Dairy-Farm-apk

Inside it, the APK is:
Rankawat-Dairy-Farm.apk

IMPORTANT FOR THE EXISTING REPOSITORY:
Your current GitHub repository already has the source ZIP and a workflow file. The workflow in this package is the corrected version for that setup: it automatically extracts the ZIP before building.

If you are using the existing repository, replace its .github/workflows/build-apk.yml with the workflow in this package. Then open GitHub Actions and run "Build Rankawat Dairy Farm APK".
